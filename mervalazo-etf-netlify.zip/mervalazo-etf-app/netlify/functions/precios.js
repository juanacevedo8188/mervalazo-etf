exports.handler = async function(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Content-Type": "application/json",
  };

  async function fetchJSON(url, ms = 6000) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), ms);
    try {
      const res = await fetch(url, { signal: controller.signal });
      clearTimeout(timeout);
      if (!res.ok) return null;
      return await res.json();
    } catch(e) { clearTimeout(timeout); return null; }
  }

  try {
    // ── DÓLAR ──────────────────────────────────────────────────────────────
    const [dolarData, rpData, mmData, mervalData] = await Promise.all([
      fetchJSON("https://dolarapi.com/v1/dolares"),
      fetchJSON("https://api.argentinadatos.com/v1/finanzas/indices/riesgo-pais/ultimo"),
      fetchJSON("https://api.argentinadatos.com/v1/finanzas/fci/mercadoDinero/ultimos"),
      fetchJSON("https://api.argentinadatos.com/v1/finanzas/indices/merval/ultimo"),
    ]);

    // Dólar
    const dolares = {};
    if (dolarData && Array.isArray(dolarData)) {
      dolarData.forEach(d => { dolares[d.casa] = { compra: d.compra, venta: d.venta, nombre: d.nombre }; });
    }
    const ccl = dolares.ccl?.venta || 1200;

    // Riesgo país
    const riesgoPais = rpData?.valor || null;

    // Money market — mejor TNA
    let tnaMM = 0.28;
    if (mmData && Array.isArray(mmData)) {
      const fondosMap = {};
      mmData.forEach(f => { if (!fondosMap[f.fondo] || fondosMap[f.fondo].fecha < f.fecha) fondosMap[f.fondo] = f; });
      const top = Object.values(fondosMap).sort((a,b) => (b.tna||0)-(a.tna||0))[0];
      if (top?.tna) tnaMM = top.tna;
    }

    // Merval
    const merval = mervalData ? { valor: mervalData.valor, variacion: mervalData.variacion || 0 } : null;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ dolares, ccl, riesgoPais, tnaMM, merval, timestamp: new Date().toISOString() }),
    };
  } catch(e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
  }
};
